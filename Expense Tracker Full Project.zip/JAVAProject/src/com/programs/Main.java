package com.programs;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        new Login();
//        new Entries_Table();
//        try {
//            new History();
//        } catch (IOException ignored) {
//
//        }
    }
}
